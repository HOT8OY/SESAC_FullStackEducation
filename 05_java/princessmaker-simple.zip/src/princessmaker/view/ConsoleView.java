package princessmaker.view;

import princessmaker.model.Princess;

import java.util.Scanner;

public class ConsoleView {
    Scanner sc = new Scanner(System.in);

    // 메서드
    // 환영메시지 출력
    public void showWelcome(){
        System.out.println("Princess Maker를 시작합니다!");
    }
    public String inputName(){
        System.out.print("Princess의 이름을 설정해주세요 : ");
        String name = sc.nextLine().trim();
        return name;
    }
    // 활동 선택
    public int selectActivity(Princess princess){
        System.out.println("\n==============================");
        System.out.println(princess.getFormattedDate());
        System.out.println("오늘은 어떤 활동을 하실건가요?");
        System.out.println("1. 운동(체력↑↑, 지능↑)");
        System.out.println("2. 공부(지능↑↑, 매력↑)");
        System.out.println("3. 사교(매력↑↑, 체력↑)");
        return sc.nextInt();
    }
    // 활동 중 화면
    public void showActivityProgress(String activityName, String message) {
        System.out.println("\n" + message);
        System.out.println("진행중...");
    }
    // 활동 결과
    public void showActivityResult(String stat1, int amount1, String stat2, int amount2, Princess princess) {
        System.out.println("\n대성공!!");
        System.out.println(stat1 + "이(가) " + amount1 + "상승했습니다!");
        System.out.println(stat2 + "이(가) " + amount2 + "상승했습니다!");
        System.out.println("[체력 : " + princess.getPhysical() + "] [지력 : " + princess.getIntelligence() + "] [매력 : " + princess.getCharm() + "]" );
    }
    // 12개월 경과 후 직업선택
    public int selectJob(Princess princess) {
        System.out.println("12개월이 지났습니다!");
        System.out.println(princess.getName() + "의 직업을 선택해주세요.");
        System.out.println("1. 군인 (체력 보정 +50%)");
        System.out.println("2. 학자 (지능 보정 +50%)");
        System.out.println("3. 연예인 (매력 보정 +50%)");
        System.out.print("번호를 선택하세요 : ");
        return sc.nextInt();
    }
    public void showJobMessage(Princess princess) {
        System.out.println(princess.getName() + "은(는) " + princess.getJob().getJobName() + "에 취직했다!");
        System.out.println("이제부터 직업에 따른 능력치 상승률이 증가합니다!");
    }
    public void showEnding(String endingName, String message){
        System.out.println("게임 종료!");
        System.out.println("엔딩: " + endingName);
        System.out.println(message);
    }
    public void close(){
        sc.close();
    }
}

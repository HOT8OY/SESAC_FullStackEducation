package com.ohgiraffers.section01.insert;

public class Application {
    public static void main(String[] args) {
        
    }
}
